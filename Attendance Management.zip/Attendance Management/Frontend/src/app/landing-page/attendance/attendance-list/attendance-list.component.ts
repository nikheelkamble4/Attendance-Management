import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Attendance } from 'src/app/model/attendance';
import { AttendanceService } from 'src/app/service/attendance.service';

@Component({
  selector: 'app-attendance-list',
  templateUrl: './attendance-list.component.html',
  styleUrls: ['./attendance-list.component.css']
})
export class AttendanceListComponent implements OnInit {

  attendances: Attendance[];


  constructor(private attendanceService: AttendanceService, private router: Router) { }

  ngOnInit(): void {
    this.getAttendance();
  }

  getAttendance(){
    this.attendanceService.getAttendanceList().subscribe(data => {
      this.attendances = data;
    });
  }

  updateAttendance(id: number){
    console.log(id);
    this.router.navigate(['/landing-page/update-attendance', id]);
  }



  deleteAttendance(id: number){
    // console.log(id);
    // this.router.navigate(['/landing-page/delete-user', id]);
    this.attendanceService.deleteAttendance(id).subscribe(
      data => {
        console.log(data);
        this.getAttendance();
      }, error => {
        console.log("Not Delete")
      }
    )

}

}
