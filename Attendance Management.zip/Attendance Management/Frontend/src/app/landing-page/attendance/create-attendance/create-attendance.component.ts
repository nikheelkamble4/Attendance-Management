import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Attendance } from 'src/app/model/attendance';
import { AttendanceService } from 'src/app/service/attendance.service';

@Component({
  selector: 'app-create-attendance',
  templateUrl: './create-attendance.component.html',
  styleUrls: ['./create-attendance.component.css']
})
export class CreateAttendanceComponent implements OnInit {

  attendance: Attendance = new Attendance();

  constructor(private attendanceService: AttendanceService, private router: Router) { }

  ngOnInit(): void {
  }

  saveUser(){
    this.attendanceService.createAttendance(this.attendance).subscribe(data=>{
      console.log(data);
      this.goToUserList();
    }, error => console.log(error));
  }

  goToUserList(){
    this.router.navigate(['/landing-page/attendance-list']);
  }

}
