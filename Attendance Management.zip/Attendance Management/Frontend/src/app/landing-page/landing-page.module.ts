import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingPageRoutingModule } from './landing-page-routing.module';
import { LandingPageComponent } from './landing-page.component';

import { CreateUserComponent } from './user/create-user/create-user.component';
import { UpdateUserComponent } from './user/update-user/update-user.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { FormsModule } from '@angular/forms';


import { CreateAttendanceComponent } from './attendance/create-attendance/create-attendance.component';
import { UpdateAttendanceComponent } from './attendance/update-attendance/update-attendance.component';
import { AttendanceListComponent } from './attendance/attendance-list/attendance-list.component';



@NgModule({
  declarations: [
    LandingPageComponent,

    CreateUserComponent,
    UpdateUserComponent,
    UserListComponent,    
    CreateAttendanceComponent,
    UpdateAttendanceComponent,
    AttendanceListComponent,

  ],
  imports: [
    CommonModule,
    LandingPageRoutingModule,
    FormsModule,

  ]
})
export class LandingPageModule { }
