import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Attendance } from '../model/attendance';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  private baseUrl="http://localhost:8080/attendance";
  constructor(private httpclient: HttpClient) { }


  createAttendance(attendance:Attendance): Observable<any>{
    return this.httpclient.post<any>(`${this.baseUrl}`, attendance);
  }
  getAttendanceList(): Observable<Attendance[]>{
    return this.httpclient.get<Attendance[]>(`${this.baseUrl}`);
  }
  getAttendanceById(id: number): Observable<Attendance>{
    return this.httpclient.get<Attendance>(`${this.baseUrl}/${id}`);
  }
  updateAttendance(id: number, attendance: Attendance): Observable<Object>{
    return this.httpclient.put(`${this.baseUrl}`,attendance);
  }

  deleteAttendance(id: number): Observable<Object>{
    return this.httpclient.delete(`${this.baseUrl}/${id}`);
  }
}
