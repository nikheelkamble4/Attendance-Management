export class User {

  userId: number;
  userName: string;
  type: String;
  bname:String;
  password: string;
  city: string;
  psid: string;


}
