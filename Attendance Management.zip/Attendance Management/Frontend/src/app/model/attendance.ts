export class Attendance {

    attid: number;
    psid: String;
    con: String;
    attdate: Date;
    type: String;
    bname:String;
    hrs: number;
  
  }
  